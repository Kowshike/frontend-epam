package org.example;

import org.testng.annotations.Test;

public class toverify {
    @Test
    void test()
    {
        System.out.println("welcome");
    }
}
