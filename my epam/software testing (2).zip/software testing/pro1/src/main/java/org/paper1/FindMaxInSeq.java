package org.paper1;
import java.util.Scanner;

public class FindMaxInSeq {
    public static int max(Scanner scanner) {
        int maxValue = Integer.MIN_VALUE;
        int value;
        do {
            value = scanner.nextInt();
            if (value != 0 && value > maxValue) {
                maxValue = value;
            }
        } while (value != 0);

        return maxValue;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int max = max(scanner);
        System.out.println(max);
    }
}
