package org.paper1;
//25
public enum Direction {
    NORTH(0), NORTHEAST(45), EAST(90), SOUTHEAST(135),
    SOUTH(180), SOUTHWEST(225), WEST(270), NORTHWEST(315);

    private final int degrees;

    Direction(int degrees) {
        this.degrees = degrees;
    }

    public static Direction ofDegrees(int degrees) {
        degrees = (degrees % 360 + 360) % 360; // Adjust degrees to [0; 360) range
        for (Direction direction : values()) {
            if (direction.degrees == degrees) {
                return direction;
            }
        }
        return null;
    }

    public static Direction closestToDegrees(int degrees) {
        degrees = (degrees % 360 + 360) % 360; // Adjust degrees to [0; 360) range
        Direction closestDirection = null;
        int minDifference = Integer.MAX_VALUE;

        for (Direction direction : values()) {
            int difference = Math.abs(direction.degrees - degrees);
            if (difference < minDifference) {
                minDifference = difference;
                closestDirection = direction;
            }
        }

        return closestDirection;
    }

    public Direction opposite() {
        int oppositeDegrees = (degrees + 180) % 360; // Calculate opposite degrees
        return ofDegrees(oppositeDegrees);
    }

    public int differenceDegreesTo(Direction other) {
        int difference = (other.degrees - this.degrees + 360) % 360; // Calculate positive difference
        return Math.min(difference, 360 - difference); // Choose the smaller of the two possible differences
    }

    public static void main(String[] args) {
        // Example usage
        Direction direction = Direction.NORTH;
        System.out.println("Opposite direction: " + direction.opposite());

        int degrees1 = 30;
        Direction closestDirection1 = Direction.closestToDegrees(degrees1);
        System.out.println("Closest direction to " + degrees1 + " degrees: " + closestDirection1);

        int degrees2 = 200;
        Direction closestDirection2 = Direction.closestToDegrees(degrees2);
        System.out.println("Closest direction to " + degrees2 + " degrees: " + closestDirection2);
    }
}