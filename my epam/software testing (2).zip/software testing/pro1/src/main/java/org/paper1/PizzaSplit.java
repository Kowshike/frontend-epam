package org.paper1;

import java.util.Scanner;
//17
public class PizzaSplit {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of people: ");
        int numberOfPeople = scanner.nextInt();

        System.out.print("Enter the number of pieces per pizza: ");
        int piecesPerPizza = scanner.nextInt();

        int minimumPizzas = calculateMinimumPizzas(numberOfPeople, piecesPerPizza);

        System.out.println("Minimum number of pizzas: " + minimumPizzas);
    }

    private static int calculateMinimumPizzas(int numberOfPeople, int piecesPerPizza) {
        int totalSlices = numberOfPeople * 8;
        return (totalSlices + piecesPerPizza - 1) / piecesPerPizza;
    }
}