package org.paper1;

import java.util.OptionalInt;
import java.util.Scanner;

public class MaxMethod {
    public static OptionalInt max(int[] values) {
        if (values == null || values.length == 0) {
            return OptionalInt.empty();
        }

        int max = values[0];
        for (int value : values) {
            if (value > max) {
                max = value;
            }
        }

        return OptionalInt.of(max);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] vals = new int[n];
        for(int i=0; i<n; i++) vals[i] = sc.nextInt();
        OptionalInt result = org.example.MaxMethod.max(vals);

        System.out.println(result.getAsInt());
    }
}
