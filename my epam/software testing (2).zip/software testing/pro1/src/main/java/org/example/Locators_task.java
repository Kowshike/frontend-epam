package org.example;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

public class Locators_task {
    public static WebDriver driver;
    public static void main(String[] args) throws InterruptedException {

        WebDriverManager.chromedriver().setup();
        driver=new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

        driver.get("https://lms.kluniversity.in/login/index.php");
        // driver.findElement(By.xpath("/html[1]/body[1]/div[1]/b[1]/font[1]/div[1]/footer[1]/div[1]/div[1]/div[3]/section[1]/ul[1]/li[5]/a[1]")).click();
        highlight(driver,driver.findElement(By.id("username")));
        driver.findElement(By.id("username")).sendKeys("2100031921");
        Thread.sleep(3000);
        highlight(driver,driver.findElement(By.name("password")));
        driver.findElement(By.name("password")).sendKeys("Kowshike@987");
        Thread.sleep(3000);
        highlight(driver,driver.findElement(By.cssSelector("#loginbtn")));
        Thread.sleep(3000);

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.findElement(By.cssSelector("#loginbtn")).click();
        Thread.sleep(3000);

        highlight(driver,driver.findElement(By.xpath("/html[1]/body[1]/div[4]/header[2]/nav[1]/div[1]/div[1]/ul[1]/li[2]/a[1]")));
        driver.findElement(By.xpath("/html[1]/body[1]/div[4]/header[2]/nav[1]/div[1]/div[1]/ul[1]/li[2]/a[1]")).click();

        highlight(driver,driver.findElement(By.className("card-img dashboard-card-img")));
        driver.findElement(By.className("card-img dashboard-card-img")).click();

//        highlight(driver,driver.findElement(By.xpath("/html[1]/body[1]/div[4]/div[1]/div[2]/div[1]/div[1]/section[1]/div[1]/aside[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/button[1]/span[1]")));
//        driver.findElement(By.className("name attribute is not available for this element")).click();

    }

    public static void highlight(WebDriver driver, WebElement element) {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: Violet; border: px solid red;');", element);
    }

}
