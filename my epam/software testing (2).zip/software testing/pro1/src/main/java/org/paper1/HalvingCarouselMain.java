package org.paper1;
//17
import java.util.ArrayList;
import java.util.List;

class CarouselRun1 {
    private final List<Integer> run;

    public CarouselRun1(List<Integer> run) {
        this.run = run;
    }

    public boolean isFinished() {
        return run.isEmpty();
    }

    public int next() {
        if (!isFinished()) {
            return run.remove(0);
        }
        return -1;
    }
}

class DecrementingCarouselw {
    protected List<Integer> elements;

    public DecrementingCarouselw(int... elements) {
        this.elements = new ArrayList<>();
        for (int element : elements) {
            this.elements.add(element);
        }
    }

    public void addElement(int element) {
        elements.add(element);
    }

    public CarouselRun run() {
        List<Integer> run = new ArrayList<>(elements);
        elements.clear();
        return new CarouselRun(run);
    }
}

class HalvingCarousel extends DecrementingCarousel {
    public HalvingCarousel(int... elements) {
        super(elements);
    }

    @Override
    public void addElement(int element) {
        if (element > 0) {
            elements.add(element / 2);
        }
    }
}

public class HalvingCarouselMain {
    public static void main(String[] args) {
        DecrementingCarousel carousel = new HalvingCarousel(7);
        carousel.addElement(20);
        carousel.addElement(30);
        carousel.addElement(10);

        CarouselRun run = carousel.run();

        while (!run.isFinished()) {
            System.out.println(run.next());
        }
    }
}