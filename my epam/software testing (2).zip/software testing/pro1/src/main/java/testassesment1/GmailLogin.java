package testassesment1;


import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GmailLogin {
    public static void main(String[] args) {
        WebDriver driver; //driver declaration
        System.out.println("opening in browser");
        WebDriverManager.chromedriver().setup();
        driver=new ChromeDriver();//using chrome
        driver.get("https://accounts.google.com");
        System.out.println(driver.getTitle());
        System.out.println(driver.getPageSource());

        System.out.println("STATIC LOCATORS");
        driver.findElement(By.id("identifierId")).sendKeys("kowshike123@gmail.com");
        driver.findElement(By.xpath("//span[normalize-space()='Next']")).click();
        driver.findElement(By.name("Passwd")).sendKeys("Kowshike@123");
        driver.findElement(By.xpath("//span[normalize-space()='Next']")).click();

    }
}