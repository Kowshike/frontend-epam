package org.paper1;

import java.util.Scanner;

public class HelloStrangers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int strangersCount = scanner.nextInt();
        if (strangersCount == 0) {
            System.out.println("Oh, it looks like there is no one here");
        } else if (strangersCount < 0) {
            System.out.println("Seriously? Why so negative?");
        } else {
            scanner.nextLine();
            for (int i = 0; i < strangersCount; i++) {
                String strangerName = scanner.nextLine();
                if (!strangerName.isEmpty()) {
                    System.out.println("Hello, " + strangerName);
                } else {
                    System.out.println("Hello, Stranger");
                }
            }
        }
    }
}
