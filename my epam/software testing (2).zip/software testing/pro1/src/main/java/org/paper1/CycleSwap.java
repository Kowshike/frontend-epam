package org.paper1;

import java.util.Arrays;

public class CycleSwap {
    public static void cycleSwap(int[] array) {
        if (array == null || array.length <= 1) {
            return;
        }

        int lastElement = array[array.length - 1];

        for (int i = array.length - 1; i > 0; i--) {
            array[i] = array[i - 1];
        }

        array[0] = lastElement;
    }

    public static void cycleSwap(int[] array, int shift) {
        if (array == null || array.length <= 1) {
            return;
        }

        shift %= array.length;

        reverseArray(array, 0, array.length - 1);
        reverseArray(array, 0, shift - 1);
        reverseArray(array, shift, array.length - 1);
    }

    private static void reverseArray(int[] array, int start, int end) {
        while (start < end) {
            int temp = array[start];
            array[start] = array[end];
            array[end] = temp;
            start++;
            end--;
        }
    }

    public static void main(String[] args) {
        // Example usage
        int[] array1 = {1, 3, 2, 7, 4};
        cycleSwap(array1);
        System.out.println("After cycleSwap(array): " + Arrays.toString(array1));

        int[] array2 = {1, 3, 2, 7, 4};
        cycleSwap(array2, 2);
        System.out.println("After cycleSwap(array, 2): " + Arrays.toString(array2));

        int[] array3 = {1, 3, 2, 7, 4};
        cycleSwap(array3, 5);
        System.out.println("After cycleSwap(array, 5): " + Arrays.toString(array3));
    }
}