package org.example;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class Git_account_using_links {
    public static void main(String[] args) {
        WebDriver driver; //driver declaration
        System.out.println("opening in browser");
        WebDriverManager.chromedriver().setup();//setting up driver manager
        driver=new ChromeDriver();//using chrome
        driver.get("https://github.com/");//driver works using get method & get expects string url.
        driver.findElement(By.xpath("//a[@class='HeaderMenu-link HeaderMenu-link--sign-in flex-shrink-0 no-underline d-block d-lg-inline-block border border-lg-0 rounded rounded-lg-0 p-2 p-lg-0']")).click();
      //  System.out.println(driver.getTitle());//display the title in my console.
      //  System.out.println(driver.getPageSource());//get the the page source in console.

//        System.out.println("STATIC LOCATORS");
        driver.findElement(By.id("login_field")).sendKeys("kowshike123@gmail.com");
        driver.findElement(By.cssSelector("#password")).sendKeys("Kowshike@123");
        driver.findElement(By.name("commit")).submit();
//        driver.findElement(By.className("nav-input nav-progressive-attribute")).sendKeys("dell");//if id is not found use "class Name"

    }
}