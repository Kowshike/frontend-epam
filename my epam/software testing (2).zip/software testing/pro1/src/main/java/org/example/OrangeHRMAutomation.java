package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;

import java.time.Duration;
import java.util.List;

public class OrangeHRMAutomation {
    public static void main(String[] args) {
        WebDriver driver;
        WebDriverManager.chromedriver().setup(); // Automatically manages the ChromeDriver version
        driver = new ChromeDriver(); // Initialize the Chrome browser

        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Create WebDriverWait instance

            // Step 1: Navigate to the OrangeHRM login page
            driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
            System.out.println("Page Title: " + driver.getTitle());
            System.out.println("Current URL: " + driver.getCurrentUrl());

            // Step 2: Log in with Admin credentials
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username"))).sendKeys("Admin");
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("password"))).sendKeys("admin123");
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']"))).click();
Thread.sleep(3000);
            // Step 3: Click on the PIM tab
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='PIM']"))).click();
            Thread.sleep(6000);
            // Step 4: Click the "Add" button
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Add']"))).click();
            Thread.sleep(6000);
            // Step 5: Fill in employee details
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("firstName"))).sendKeys("Emmadisetty");
            driver.findElement(By.name("lastName")).sendKeys("Kowshik");

            Thread.sleep(5000);
            // Step 6: Check 'Create Login Details' checkbox
            WebElement createLoginDetailsCheckbox = driver.findElement(By.cssSelector(".oxd-switch-input"));
            if (!createLoginDetailsCheckbox.isSelected()) {
                createLoginDetailsCheckbox.click(); // Ensure checkbox is checked
            }
            Thread.sleep(3000);
            // Step 7: Enter login credentials for the employee
            WebElement usernameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[text()='Username']/../following-sibling::div/input")));
            usernameField.sendKeys("kowshikemmadisetty");
            Thread.sleep(6000);
            WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[text()='Password']/../following-sibling::div/input")));
            passwordField.sendKeys("Kowshike@1234");
            Thread.sleep(3000);
            WebElement confirmPasswordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[text()='Confirm Password']/../following-sibling::div/input")));
            confirmPasswordField.sendKeys("Kowshike@1234");

            Thread.sleep(6000);
            // Step 8: Click the "Save" button
            WebElement saveButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']")));
            saveButton.click();
            Thread.sleep(6000);
            // Step 9: Navigate to the Admin tab
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Admin']"))).click();
            Thread.sleep(3000);
            // Step 10: Click on "User Management" and then the "Add" button
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='User Management']"))).click();
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Add']"))).click();
            Thread.sleep(3000);
            // Step 11: Select "Admin" role
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='User Role']/following::div[1]"))).click();
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='listbox']//span[text()='Admin']"))).click();
            Thread.sleep(3000);
            // Step 12: Select the status as "Enabled"
            WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='Status']/following::div[1]")));
            statusDropdown.click();
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='listbox']//span[text()='Enabled']"))).click();

            // Step 13: Provide unique username and password for the admin user
            WebElement employeeNameInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Type for hints...']")));
            employeeNameInput.sendKeys("Emmad");
            Thread.sleep(6000);
            // Wait for the suggestions dropdown and select the user
            List<WebElement> suggestions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(@class, 'oxd-autocomplete-option')]")));
            for (WebElement suggestion : suggestions) {
                if (suggestion.getText().contains("Emmadisetty Kowshik")) {
                    suggestion.click(); // Click the suggestion
                    break;
                }
            }
            Thread.sleep(6000);
            // Step 14: Set admin credentials
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("document.querySelector('.oxd-input.oxd-input--focus.oxd-input--error').value='adminkowshik';");
            js.executeScript("document.querySelector('.oxd-input.oxd-input--focus.oxd-input--error').dispatchEvent(new Event('input', { bubbles: true }));");

            WebElement adminPasswordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Password']")));

            adminPasswordField.sendKeys("adminpass123");

            WebElement adminConfirmPasswordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Confirm Password']")));

            adminConfirmPasswordField.sendKeys("adminpass123");

            Thread.sleep(3000);

            // Step 15: Click "Save" to create the admin user
            saveButton.click(); // Reuse the previously declared saveButton
            Thread.sleep(3000);

            // Step 16: Log out by clicking the profile icon and selecting "Logout"
            WebElement userDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='oxd-userdropdown-tab']")));
            userDropdown.click();
            WebElement logoutButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Logout']")));
            logoutButton.click();
            Thread.sleep(3000);

            // Step 17: Log in with the new admin credentials
            WebElement loginUsernameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
            loginUsernameField.sendKeys("adminkowshik");

            WebElement loginPasswordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("password")));
            loginPasswordField.sendKeys("adminpass123");

            WebElement loginSubmitButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']")));
            loginSubmitButton.click();

            Thread.sleep(3000);

            // Step 18: Verify login success
            System.out.println("New Admin Page Title: " + driver.getTitle());

        } catch (Exception e) {
            e.printStackTrace(); // Print any exceptions for debugging
        } finally {
            // Step 19: Close the browser
            driver.quit();
        }
    }
}