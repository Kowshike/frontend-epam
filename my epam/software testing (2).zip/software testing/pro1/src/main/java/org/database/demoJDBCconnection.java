package org.database;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import java.sql.*;

public class demoJDBCconnection {
    public static void main(String[] args) throws SQLException {
        String host = "127.0.0.1";
        String port = "3305";
        Connection con = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/swtesting", "root", "Kowshike@123");
        Statement s = con.createStatement();
        ResultSet rs = s.executeQuery("select * from credentials where username='kowshikemmadisetty'");
        while (rs.next()) {
            WebDriver driver;
            WebDriverManager.edgedriver().setup();
            driver=new EdgeDriver();
            driver.get("https://www.github.com/login");
            driver.findElement(By.id("login_field")).sendKeys(rs.getString("username"));
            driver.findElement(By.id("password")).sendKeys(rs.getString("password"));
            System.out.println(rs.getString("username"));
            System.out.println(rs.getInt("password"));

        }
    }

}