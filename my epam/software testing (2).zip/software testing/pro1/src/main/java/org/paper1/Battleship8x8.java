package org.paper1;

//28
public class Battleship8x8 {
    private long ships;
    private long shots;

    public Battleship8x8(long ships) {
        this.ships = ships;
        this.shots = 0L;
    }

    public boolean shoot(String shot) {
        int row = 8 - Integer.parseInt(shot.substring(1, 2));
        int col = shot.charAt(0) - 'A';

        long shotMask = 1L << (row * 8 + col);

        if ((shots & shotMask) != 0) {
            // Already shot at this position
            return false;
        }

        shots |= shotMask;

        return (ships & shotMask) != 0;
    }

    public String state() {
        StringBuilder result = new StringBuilder();
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                long position = 1L << (row * 8 + col);
                if ((shots & position) != 0) {
                    result.append((ships & position) != 0 ? '☒' : '×');
                } else {
                    result.append((ships & position) != 0 ? '☐' : '.');
                }
            }
            result.append('\n');
        }
        return result.toString().trim();
    }

    public static void main(String[] args) {
        // Example usage
        long map = 0b11110000_00000111_00000000_00110000_00000010_01000000_00000000_00000000L;
        Battleship8x8 battle = new Battleship8x8(map);
        String[] shots = {"A1", "B2", "C3", "D4"};
        for (String shot : shots) {
            battle.shoot(shot);
        }
        System.out.println(battle.state());
    }
}

