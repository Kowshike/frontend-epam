package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class openwebpage {
    public static void main(String[] args) {
        WebDriver driver;
        System.out.println("testing on open browser"); //for our confimation
        WebDriverManager.edgedriver().setup();
        driver=new EdgeDriver();//instantion of edge browser
        driver.get("https://www.amazon.org");
        System.out.println(driver.getTitle());
        driver.quit();

    }
}
