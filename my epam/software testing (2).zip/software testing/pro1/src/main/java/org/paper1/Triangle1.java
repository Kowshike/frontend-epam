package org.paper1;

public interface Triangle1 {
}
