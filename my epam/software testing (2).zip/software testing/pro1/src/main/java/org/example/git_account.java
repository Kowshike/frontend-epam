package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class git_account {
    public static void main(String[] args) {
        WebDriver driver; //driver declaration
        System.out.println("opening in browser");
        WebDriverManager.chromedriver().setup();//setting up driver manager
        driver=new ChromeDriver();//using chrome
        driver.get("https://github.com/login");//driver works using get method & get expects string url.
        System.out.println(driver.getTitle());//display the title in my console.
        System.out.println(driver.getPageSource());//get the the page source in console.

        //concept heading=cls starts on 12/1/24
        System.out.println("STATIC LOCATORS");
        driver.findElement(By.id("login_field")).sendKeys("kowshike123@gmail.com");
        driver.findElement(By.id("password")).sendKeys("Kowshike@123");
        driver.findElement(By.name("commit")).submit();
//        driver.findElement(By.className("nav-input nav-progressive-attribute")).sendKeys("dell");//if id is not found use "class Name"

    }
}