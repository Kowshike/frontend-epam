package org.paper1;
//26
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
public class CatchEmAl {
    public static void main(String[] args) {
        try {
            riskyMethod();
        } catch (ArithmeticException | NumberFormatException e) {
            System.err.println(e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void riskyMethod() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a file name:");
        String fileName = scanner.nextLine();

        try {
            readFile(fileName);
        } catch (FileNotFoundException e) {
            throw new IllegalArgumentException("Resource is missing", e);
        } catch (IOException e) {
            throw new IllegalArgumentException("Resource error", e);
        }
    }

    private static void readFile(String fileName) throws IOException {
        // Simulating reading from a file
        throw new IOException("Unable to read from file");
    }
}
