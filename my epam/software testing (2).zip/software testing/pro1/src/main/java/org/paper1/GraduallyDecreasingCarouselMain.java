package org.paper1;

//18
import java.util.ArrayList;
import java.util.List;

class CarouselRun {
    final List<Integer> run;

    public CarouselRun(List<Integer> run) {
        this.run = run;
    }

    public boolean isFinished() {
        return run.isEmpty();
    }

    public int next() {
        if (!isFinished()) {
            return run.remove(0);
        }
        return -1;
    }
}

class DecrementingCarousel {
    protected List<Integer> elements;

    public DecrementingCarousel(int... elements) {
        this.elements = new ArrayList<>();
        for (int element : elements) {
            this.elements.add(element);
        }
    }

    public void addElement(int element) {
        elements.add(element);
    }

    public CarouselRun run() {
        List<Integer> run = new ArrayList<>(elements);
        elements.clear();
        return new CarouselRun(run);
    }

    public int next() {
        return 0;
    }
}

class GraduallyDecreasingCarousel extends DecrementingCarousel {
    private int currentDecrement;

    public GraduallyDecreasingCarousel(int... elements) {
        super(elements);
        currentDecrement = 1;
    }

    @Override
    public CarouselRun run() {
        List<Integer> run = new ArrayList<>();
        for (int element : elements) {
            if (element > 0) {
                run.add(element);
            }
        }
        elements.clear();
        currentDecrement = 1;
        return new CarouselRun(run);
    }

    @Override
    public void addElement(int element) {
        if (element > 0) {
            elements.add(element - currentDecrement);
            currentDecrement++;
        }
    }
}

public class GraduallyDecreasingCarouselMain {
    public static void main(String[] args) {
        DecrementingCarousel carousel = new GraduallyDecreasingCarousel(7);
        carousel.addElement(20);
        carousel.addElement(30);
        carousel.addElement(10);

        CarouselRun run = carousel.run();

        while (!run.isFinished()) {
            System.out.println(run.next());
        }
    }
}