package workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class GoogleLoginTest {

    public static void main(String[] args) {
        // Setup WebDriverManager for Chrome
        WebDriverManager.chromedriver().setup();

        // Initialize ChromeDriver
        WebDriver driver = new ChromeDriver();

        // Test Case 1: Verify the presence of the "Sign in" link
        driver.get("https://accounts.google.com/v3/signin/identifier?continue=https%3A%2F%2Fwww.google.com%2F%3Fptid%3D19027681%26ptt%3D8%26fpts%3D0&ec=futura_hpp_co_si_001_p&ifkv=ARZ0qKKJUxguyyGs_ss7Gwjq0QVp8YwQJBRdQFZdNZAhWuAFX25IWyQU6la40IILc5kVShIOd_YAwQ&flowName=GlifWebSignIn&flowEntry=ServiceLogin&dsh=S-1861250663%3A1711429649321038&theme=mn&ddm=0");
        WebElement signInLink = driver.findElement(By.linkText("Sign in"));
        if (signInLink.isDisplayed()) {
            System.out.println("Test Case 1 Passed: 'Sign in' link is present.");
        } else {
            System.out.println("Test Case 1 Failed: 'Sign in' link is not present.");
        }

        // Test Case 2: Verify the presence of the "Forgot password?" link
        WebElement forgotPasswordLink = driver.findElement(By.partialLinkText("Forgot"));
        if (forgotPasswordLink.isDisplayed()) {
            System.out.println("Test Case 2 Passed: 'Forgot password?' link is present.");
        } else {
            System.out.println("Test Case 2 Failed: 'Forgot password?' link is not present.");
        }

        // Test Case 3: Verify the absence of the "Create account" link
        try {
            WebElement createAccountLink = driver.findElement(By.partialLinkText("Create"));
            System.out.println("Test Case 3 Failed: 'Create account' link is present.");
        } catch (Exception e) {
            System.out.println("Test Case 3 Passed: 'Create account' link is not present.");
        }

        // Test Case 4: Verify the redirection to the sign-in page
        driver.get("https://www.google.com");
        WebElement googleSignInLink = driver.findElement(By.linkText("Sign in"));
        googleSignInLink.click();
        String currentUrl = driver.getCurrentUrl();
        if (currentUrl.equals("https://google.com/login")) {
            System.out.println("Test Case 4 Passed: Redirected to the login page successfully.");
        } else {
            System.out.println("Test Case 4 Failed: Redirected to incorrect page.");
        }

        // Close the browser
        driver.quit();
    }
}
