package org.paper1;
//14
import java.util.Scanner;
import java.util.Scanner;

public class Snail {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt(); // distance climbed during the day
        int b = scanner.nextInt(); // distance slid down during the night
        int h = scanner.nextInt(); // height of the tree

        // If the snail climbs more than the height of the tree in a day, it will reach the top on the first day
        if (a >= h) {
            System.out.println("1");
            return;
        }

        int climb_distance = a - b; // distance climbed each day

        // If the snail cannot climb at all or the distance climbed is less than or equal to 0, it will never reach the top
        if (climb_distance <= 0) {
            System.out.println("Impossible");
            return;
        }

        // Calculate the number of days required to reach the top of the tree
        int days = (h - a + climb_distance - 1) / climb_distance + 1;

        // Print the number of days
        System.out.println(days);
    }
}