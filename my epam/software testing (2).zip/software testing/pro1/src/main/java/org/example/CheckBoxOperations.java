package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class CheckBoxOperations {

    public static void main(String[] args) throws InterruptedException {
        WebDriver driver;
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("file:///S:/3.2/software%20testing/alert.html");

        /**
         * Validate isSelected and click
         */

        WebElement checkBoxSelected = driver.findElement(By.name("group1"));
        Thread.sleep(3000);
        boolean isSelected = checkBoxSelected.isSelected();

        // performing click operation if element is not selected
        if (!isSelected) {
            checkBoxSelected.click();
        }

        WebElement checkBoxDisplayed = driver.findElement(By.name("group1"));
        boolean isDisplayed = checkBoxDisplayed.isDisplayed();

        // performing click operation if element is displayed
        if (isDisplayed) {
            checkBoxDisplayed.click();
        }

    }
}
