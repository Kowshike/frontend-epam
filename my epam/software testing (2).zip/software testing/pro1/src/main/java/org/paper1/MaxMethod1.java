package org.paper1;

public class MaxMethod1 {
    public static int max(int[] values) {
        int maxValue = Integer.MIN_VALUE;
        for (int value : values) {
            if (value > maxValue) {
                maxValue = value;
            }
        }
        return maxValue;
    }
    public static void main(String[] args) {
        int[] vals = {-2, 0, 10, 5};
        int result = MaxMethod1.max(vals);
        System.out.println(result == 10);
    }
}