package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration; // Import Duration class
import java.util.List;

public class Explicit_wait {
    public static void main(String[] args) {
        WebDriver driver;
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();

        // Set implicit wait (optional)
        // driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        // Navigate to the URL
        driver.get("https://www.hyrtutorials.com/p/html-dropdown-elements-practice.html");

        // Explicit wait for the element with ID "ide"
        WebElement ideElement = new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.visibilityOfElementLocated(By.id("ide")));

        // Assuming there is a dropdown with id 'ide'
        Select ideDropDown = new Select(ideElement);

        // Highlight the dropdown with red color
        highlightElement(driver, ideElement, "red");

        // Print all options in the dropdown
        List<WebElement> ideDropDownOptions = ideDropDown.getOptions();
        for (WebElement option : ideDropDownOptions) {
            System.out.println(option.getText());
        }

        // Rest of your code...

        // Close the browser
        driver.quit();
    }

    // Function to highlight an element using JavaScript
    private static void highlightElement(WebDriver driver, WebElement element, String color) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].style.border='2px solid " + color + "'", element);
    }
}
