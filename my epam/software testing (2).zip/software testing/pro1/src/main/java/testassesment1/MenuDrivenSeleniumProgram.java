package testassesment1;
import java.io.IOException;
import java.util.Scanner;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.time.Duration;

public class MenuDrivenSeleniumProgram {

    private static WebDriver driver;

    public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();

        try {
            menu();
        } finally {
            driver.quit();
        }
    }

    private static void menu() {
        System.out.println("Menu Driven Selenium Program");
        System.out.println("a) Open Browser");
        System.out.println("b) Open Given URL");
        System.out.println("c) Open Browser with Credentials");
        System.out.println("d) Open URL with Invalid Credentials");
        System.out.println("e) Implement Static Locators");
        System.out.println("f) Implement CSS Selector (Dynamic)");
        System.out.println("g) Implement XPath (Dynamic)");
        System.out.println("h) Implement HTML Controls");
        System.out.println("i) Implement Alerts");
        System.out.println("j) Take a Screenshot");
        System.out.println("x) Exit");

        // You can add more options based on your specific requirements.

        // Assuming a simple console input for the menu choice
        String choice = System.console().readLine("Enter your choice: ");

        switch (choice.toLowerCase()) {
            case "a":
                openBrowser();
                break;
            case "b":
                openGivenURL("https://www.amazon.org");
                break;
            case "c":
                openBrowserWithCredentials("kowshike123@gmail.com", "Kowshike@123");
                break;
            case "d":
                openURLWithInvalidCredentials("https://www.amazon.org", "kowshike123@gmail.com", "king123");
                break;
            case "e":
                implementStaticLocators();
                break;
            case "f":
                implementCssSelector();
                break;
            case "g":
                try {
                    implementXpath();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                break;
            case "h":
                implementHtmlControls();
                break;
            case "i":
                try {
                    implementAlerts();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                break;
            case "j":
                try {
                    takeScreenshot();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                break;
            case "x":
                System.out.println("Exiting program...");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
                menu();
                break;
        }
    }

    private static void openBrowser() {
        // Open browser logic
        // You may want to navigate to a default URL or perform other actions
        System.out.println("Browser opened successfully.");
        menu();
    }

    private static void openGivenURL(String url) {
        driver.get(url);
        System.out.println("Opened URL: " + url);
        menu();
    }

    private static void openBrowserWithCredentials(String username, String password) {
        // Logic to open browser with credentials
        // You can use WebDriver methods to interact with login forms
        System.out.println("Opened browser with credentials");
        menu();
    }

    private static void openURLWithInvalidCredentials(String url, String username, String password) {
        // Logic to handle invalid credentials when opening a URL
        // You can use WebDriver methods to interact with login forms
        System.out.println("Opened URL with invalid credentials");
        menu();
    }

    private static void implementStaticLocators() {
        System.out.println("Implemented static locators");

        // Static Locators Logic
        driver.get("https://www.amazon.in");
        driver.findElement(By.id("twotabsearchtextbox")).sendKeys("dell");
        driver.findElement(By.id("nav-search-submit-button")).submit();

        // Add more logic as needed

        menu();
    }

    private static void implementCssSelector() {
        WebDriver driver;
        System.out.println("opening in browser");
        WebDriverManager.chromedriver().setup();// setting up driver manager
        driver = new ChromeDriver();// using chrome
        driver.get("https://lms.kluniversity.in/login/index.php");// driver works using get method & get expects string url.
        System.out.println(driver.getTitle());// display the title in my console.
        System.out.println(driver.getPageSource());// get the page source in console.

        // CSS Selector logic
        System.out.println("Implemented CSS selector");
        driver.findElement(By.cssSelector("#username")).sendKeys("2100031921");
        driver.findElement(By.cssSelector("input#password")).sendKeys("Kowshike@987");
        driver.findElement(By.cssSelector("#loginbtn")).click();

        // Assuming you want to navigate back to the menu after implementing CSS selector
        menu();
    }


    private static void implementXpath() throws InterruptedException {
        WebDriver driver;
        System.out.println("opening in browser");
        WebDriverManager.chromedriver().setup();// setting up driver manager
        driver = new ChromeDriver();// using chrome
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.get("https://lms.kluniversity.in/login/index.php");// driver works using get method & get expects string url.
        System.out.println(driver.getTitle());// display the title in my console.
        System.out.println(driver.getPageSource());// get the page source in console.

        // XPath logic
        System.out.println("Implemented XPath");
        driver.findElement(By.xpath("/html[1]/body[1]/div[1]/b[1]/font[1]/div[1]/footer[1]/div[1]/div[1]/div[3]/section[1]/ul[1]/li[5]/a[1]")).click();
        driver.findElement(By.id("username")).sendKeys("2100031921");
        Thread.sleep(3000);

        // Assuming you want to navigate back to the menu after implementing XPath
        menu();
    }


    private static void implementHtmlControls() {
        WebDriver driver;
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get("file:///S:/3.2/software%20testing/alert.html"); // Replace with the actual path or URL
        driver.manage().window().maximize();

        // HTML Controls Logic
        System.out.println("Implemented HTML controls");

        // Interaction with various HTML controls using WebDriver methods

        // Example of Dropdown Selection
        WebElement dropdownElement = driver.findElement(By.id("namesDropdown")); // Update with the actual ID of the dropdown
        Select dropdownSelect = new Select(dropdownElement);
        dropdownSelect.selectByIndex(3); // Index starts from 0
        dropdownSelect.selectByVisibleText("Bob");

        // Example of Checkbox Handling
        WebElement checkboxElement = driver.findElement(By.name("group1"));
        boolean isCheckboxSelected = checkboxElement.isSelected();

        if (!isCheckboxSelected) {
            checkboxElement.click();
        }

        // You can add more interactions with other HTML controls based on your specific requirements

        // Assuming you want to navigate back to the menu after implementing HTML controls
        menu();
    }


    private static void implementAlerts() throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Select the appropriate number based on your choice");
        System.out.println("1. Simple Alert");
        System.out.println("2. Confirm Alert");
        System.out.println("3. Prompt Alert");
        System.out.println("Please select one number from the above to view to alert message from the browser");

        int select;
        select = scanner.nextInt();

        switch (select) {
            case 1:
                simplealert();
                break;

            case 2:
                confirmalert();
                break;
            case 3:
                promptalert();
                break;
            default:
                System.out.println("This is not a case that you must select");
                break;

        }

        // Assuming you want to navigate back to the menu after implementing alerts
        menu();
    }

    private static void simplealert() {
        WebDriver driver;
        WebDriverManager.edgedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.hyrtutorials.com/p/alertsdemo.html");
        driver.findElement(By.id("alertBox")).click();
        System.out.println(driver.switchTo().alert().getText());
        driver.switchTo().alert().accept();
        System.out.println(driver.findElement(By.id("output")).getText());
    }

    private static void confirmalert() throws Exception {
        WebDriver driver;
        WebDriverManager.edgedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.hyrtutorials.com/p/alertsdemo.html");
        System.out.println(driver.findElement(By.id("output")).getText());
        Thread.sleep(2000);
        driver.findElement(By.id("confirmBox")).click();
        Thread.sleep(2000);
        System.out.println(driver.switchTo().alert().getText());
        Thread.sleep(2000);
        driver.switchTo().alert().accept();
        Thread.sleep(2000);
        System.out.println(driver.findElement(By.id("output")).getText());
        System.out.println(driver.findElement(By.id("output")).getText());
        Thread.sleep(2000);
        driver.findElement(By.id("confirmBox")).click();
        Thread.sleep(2000);
        System.out.println(driver.switchTo().alert().getText());
        Thread.sleep(2000);
        driver.switchTo().alert().dismiss();
        Thread.sleep(2000);
        System.out.println(driver.findElement(By.id("output")).getText());
    }

    private static void promptalert() throws Exception {
        WebDriver driver;
        WebDriverManager.edgedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.hyrtutorials.com/p/alertsdemo.html");
        System.out.println(driver.findElement(By.id("output")).getText());
        Thread.sleep(2000);
        driver.findElement(By.id("promptBox")).click();
        Thread.sleep(2000);
        System.out.println(driver.switchTo().alert().getText());
        Thread.sleep(2000);
        driver.switchTo().alert().sendKeys("Sabitha");
        driver.switchTo().alert().accept();
        Thread.sleep(2000);
        System.out.println(driver.findElement(By.id("output")).getText());
        driver.findElement(By.id("promptBox")).click();
        System.out.println(driver.switchTo().alert().getText());
        Thread.sleep(2000);
        driver.switchTo().alert().dismiss();
        Thread.sleep(2000);
        System.out.println(driver.findElement(By.id("output")).getText());
        Thread.sleep(2000);
    }


    private static void takeScreenshot() throws IOException {
        WebDriver driver;
        System.out.println("opening in browser");
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get("https://lms.kluniversity.in/login/index.php");

        // Taking a screenshot logic
        File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(screenshotFile, new File("./screenshots/test1.png"));

        // You can save or process the screenshot file as needed
        System.out.println("Screenshot taken");

        // Assuming you want to navigate back to the menu after taking a screenshot
        menu();
    }}

