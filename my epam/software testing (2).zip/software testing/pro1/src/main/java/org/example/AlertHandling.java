package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertHandling {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver;
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("file:///C:/Users/ACER/OneDrive/Desktop/alert.html");

        // Alert Box
//        WebElement alertBoxButton = driver.findElement(By.id("alertexamples"));
//        alertBoxButton.click();
//        handleAlert(driver);
//        Thread.sleep(2000);
//        System.out.println(driver.findElement(By.id("output")).getText());

        // Confirm Box (OK)
        WebElement confirmBoxButtonOK = driver.findElement(By.id("confirmexample"));
        confirmBoxButtonOK.click();
        handleAlert(driver);
        System.out.println(driver.findElement(By.id("output")).getText());

        // Confirm Box (Cancel)
        WebElement confirmBoxButtonCancel = driver.findElement(By.id("confirmexample"));
        confirmBoxButtonCancel.click();
        handleAlert(driver, false);
        System.out.println(driver.findElement(By.id("output")).getText());

        // Prompt Box (OK)
        WebElement promptBoxButtonOK = driver.findElement(By.id("promptBox"));
        promptBoxButtonOK.click();
        handlePromptAlert(driver, "Sabitha");
        System.out.println(driver.findElement(By.id("output")).getText());

        // Prompt Box (Cancel)
        WebElement promptBoxButtonCancel = driver.findElement(By.id("promptBox"));
        promptBoxButtonCancel.click();
        handlePromptAlert(driver, null);
        System.out.println(driver.findElement(By.id("output")).getText());

        driver.quit();
    }

    private static void handleAlert(WebDriver driver) {
        Alert alert = driver.switchTo().alert();
        alert.accept();
    }

    private static void handleAlert(WebDriver driver, boolean accept) {
        Alert alert = driver.switchTo().alert();
        if (accept) {
            alert.accept();
        } else {
            alert.dismiss();
        }
    }

    private static void handlePromptAlert(WebDriver driver, String inputText) {
        Alert alert = driver.switchTo().alert();
        alert.sendKeys(inputText);
        alert.accept();
    }
}
