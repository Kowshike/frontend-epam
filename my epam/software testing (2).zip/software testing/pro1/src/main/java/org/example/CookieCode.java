package org.example;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class CookieCode {
    public static void main(String args[]) throws Exception{
        WebDriverManager.edgedriver().setup();
        WebDriver driver=new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://lms.kluniversity.in/login/index.php");
        driver.manage().window().maximize();
        driver.findElement(By.id("username")).sendKeys("user");
        driver.findElement(By.id("password")).sendKeys("pass");
        driver.findElement(By.id("password")).submit();
        Thread.sleep(3000);
        for(Cookie cook:driver.manage().getCookies()){
            System.out.println(cook.getName()+" "+cook.getValue());

        }
        driver.manage().deleteCookieNamed("MoodleSession");
        driver.findElement(By.xpath("//button[@data-action='new-event-button']")).click();

    }
}
