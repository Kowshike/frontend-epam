package testassesment1;


import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropdownAndCheckboxExample {
    public static void main(String[] args) {
        WebDriver driver;
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get("file:///S:/3.2/software%20testing/alert.html"); // Replace with the actual path or URL
        driver.manage().window().maximize();

        // Dropdown Selection
        WebElement dropdownElement = driver.findElement(By.id("namesDropdown")); // Update with the actual ID of the dropdown
        Select dropdownSelect = new Select(dropdownElement);
        dropdownSelect.selectByIndex(3); // Index starts from 0
        dropdownSelect.selectByVisibleText("Bob");

        // Checkbox Handling
        WebElement checkboxElement = driver.findElement(By.name("group1"));
        boolean isCheckboxSelected = checkboxElement.isSelected();

        if (!isCheckboxSelected) {
            checkboxElement.click();
        }

    }
}
