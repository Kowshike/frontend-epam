package org.example;



import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class checkbrowser {

    @Test
    public void test() {
        WebDriver driver;
        System.out.println("Testing on open browser"); // for our confirmation
        WebDriverManager.edgedriver().setup();
        driver = new EdgeDriver();
        driver.get("https://www.amazon.org");
        System.out.println(driver.getTitle());
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get("https://www.amazon.org");
        System.out.println(driver.getTitle());
        WebDriverManager.firefoxdriver().setup();
        driver = new FirefoxDriver();
        driver.get("https://www.amazon.org");
        System.out.println(driver.getTitle());
        driver.quit();
    }

}
