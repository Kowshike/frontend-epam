package org.paper1;
//wrong approach check again
//wrong approach check again
//wrong approach check again
//wrong approach check again
//wrong approach check again


import java.util.Arrays;

public class LocalMaximaRemove {
    public static int[] removeLocalMaxima(int[] array) {
        int n = array.length;
        int count = 0;

        // Count the number of local maxima in the array
        for (int i = 1; i < n - 1; i++) {
            if (array[i] > array[i - 1] && array[i] > array[i + 1]) {
                count++;
            }
        }

        // If there are no local maxima, return a copy of the original array
        if (count == 0) {
            return Arrays.copyOf(array, n);
        }

        // Create a new array to store the result without local maxima
        int[] result = new int[n - count];
        int index = 0;

        // Copy elements to the result array, excluding local maxima
        for (int i = 0; i < n; i++) {
            if (i == 0 || i == n - 1 || (array[i] <= array[i - 1] || array[i] <= array[i + 1])) {
                result[index++] = array[i];
            }
        }

        return result;
    }

    // Example usage
    public static void main(String[] args) {
        int[] inputArray = {18, 1, 3, 6, 7, -5};
        int[] outputArray = removeLocalMaxima(inputArray);

        System.out.println("Input array: " + Arrays.toString(inputArray));
        System.out.println("Output array: " + Arrays.toString(outputArray));
    }
}