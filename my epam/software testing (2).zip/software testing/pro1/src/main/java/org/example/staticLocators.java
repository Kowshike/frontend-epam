package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;//chrome driver
import org.openqa.selenium.firefox.FirefoxDriver;


public class staticLocators {
    public static void main(String[] args) {
        WebDriver driver; //driver declaration
        System.out.println("opening in browser");
        WebDriverManager.chromedriver().setup();//setting up driver manager
        driver=new ChromeDriver();//using chrome
        driver.get("https://www.amazon.in");//driver works using get method & get expects string url.
        System.out.println(driver.getTitle());//display the title in my console.
        System.out.println(driver.getPageSource());//get the the page source in console.

        //concept heading=cls starts on 12/1/24
        System.out.println("STATIC LOCATORS");
        driver.findElement(By.id("twotabsearchtextbox")).sendKeys("dell");
        driver.findElement(By.id("nav-search-submit-button")).submit();
//        driver.findElement(By.className("nav-input nav-progressive-attribute")).sendKeys("dell");//if id is not found use "class Name"
//        System.out.println("opening in browser1");
//        WebDriverManager.chromedriver().setup();//setting up driver manager
//        driver=new FirefoxDriver();//using chrome
//        driver.get("https://www.amazon.in");//driver works using get method & get expects string url.
//        System.out.println(driver.getTitle());//display the title in my console.
//        System.out.println(driver.getPageSource());//get the the page source in console.
//
//        //concept heading=cls starts on 12/1/24
//        System.out.println("STATIC LOCATORS");
//        driver.findElement(By.id("twotabsearchtextbox")).sendKeys("dell");
//        driver.findElement(By.id("nav-search-submit-button")).submit();
////        driver.findElement(By.className("nav-input nav-progressive-attribute")).sendKeys("dell");//if id is not found use "class
    }
}
