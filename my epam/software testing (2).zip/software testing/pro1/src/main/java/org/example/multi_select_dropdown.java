package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

    public class multi_select_dropdown {
        public static void main(String[] args) throws InterruptedException {
            WebDriver driver;
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
            driver.manage().window().maximize();
            driver.get("https://www.hyrtutorials.com/p/html-dropdown-elements-practice.html");  // Replace with the actual URL

            // Assuming there is a dropdown with id 'ide'
            WebElement ideElement = driver.findElement(By.id("ide"));
            Select ideDropDown = new Select(ideElement);

            // Print all options in the dropdown
            List<WebElement> ideDropDownOptions = ideDropDown.getOptions();
            for (WebElement option : ideDropDownOptions) {
                System.out.println(option.getText());
            }

            // Select option by index
            ideDropDown.selectByIndex(0);

            // Select option by value
            ideDropDown.selectByValue("ij");

            // Select option by visible text
            ideDropDown.selectByVisibleText("NetBeans");

            // Deselect option by visible text (assuming it's a multi-select dropdown)
            // ideDropDown.deselectByVisibleText("IntelliJ IDEA");

            // Get all selected options and print their visible text
            List<WebElement> selectedOptions = ideDropDown.getAllSelectedOptions();
            for (WebElement selectedOption : selectedOptions) {
                System.out.println("Selected visible text: " + selectedOption.getText());
            }

            // Close the browser after a brief pause
            Thread.sleep(3000);
//            driver.quit();
        }
    }

