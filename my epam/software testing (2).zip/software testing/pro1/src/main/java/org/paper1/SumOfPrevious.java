package org.paper1;

import java.util.Arrays;
import java.util.Scanner;

public class SumOfPrevious {
    public static boolean[] getSumCheckArray(int[] array) {
        boolean[] result = new boolean[array.length];
        result[0] = result[1] = false;
        for (int i = 2; i < array.length; i++) {
            result[i] = array[i] == array[i - 1] + array[i - 2];
        }
        return result;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();
        System.out.println("Enter the elements of the array:");
        int[] inputArray = new int[size];
        for (int i = 0; i < size; i++) {
            inputArray[i] = scanner.nextInt();
        }
        boolean[] outputArray = getSumCheckArray(inputArray);
        System.out.println("Input Array: " + Arrays.toString(inputArray));
        System.out.println("Output Array: " + Arrays.toString(outputArray));
    }
}
