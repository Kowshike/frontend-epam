package org.paper1;
//12
import java.util.ArrayList;
import java.util.List;

class Ticket {
    private final int id;
    private final String name;
    private final int estimate;
    private boolean completed;

    public Ticket(int id, String name, int estimate) {
        this.id = id;
        this.name = name;
        this.estimate = estimate;
        this.completed = false;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getEstimate() {
        return estimate;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void complete() {
        completed = true;
    }
}

class UserStory extends Ticket {
    private final List<UserStory> dependencies;

    public UserStory(int id, String name, int estimate, List<UserStory> dependencies) {
        super(id, name, estimate);
        this.dependencies = new ArrayList<>(dependencies);
    }

    public List<UserStory> getDependencies() {
        return new ArrayList<>(dependencies);
    }

    @Override
    public void complete() {
        if (dependencies.stream().allMatch(UserStory::isCompleted)) {
            super.complete();
        }
    }

    @Override
    public String toString() {
        return "[US " + getId() + "] " + getName();
    }
}

class Bug extends Ticket {
    private final UserStory relatedUserStory;

    private Bug(int id, String name, int estimate, UserStory relatedUserStory) {
        super(id, name, estimate);
        this.relatedUserStory = relatedUserStory;
    }

    public static Bug createBug(int id, String name, int estimate, UserStory relatedUserStory) {
        if (relatedUserStory == null || !relatedUserStory.isCompleted()) {
            return null;
        }
        return new Bug(id, name, estimate, relatedUserStory);
    }

    @Override
    public String toString() {
        return "[Bug " + getId() + "] " + relatedUserStory.getName() + ": " + getName();
    }
}

class Sprint {
    private final int timeCapacity;
    private final int ticketsLimit;
    private final List<Ticket> tickets;

    public Sprint(int timeCapacity, int ticketsLimit) {
        this.timeCapacity = timeCapacity;
        this.ticketsLimit = ticketsLimit;
        this.tickets = new ArrayList<>();
    }

    public boolean addUserStory(UserStory userStory) {
        if (userStory == null || userStory.isCompleted() || !checkDependencies(userStory)) {
            return false;
        }
        return addTicket(userStory);
    }

    public boolean addBug(Bug bugReport) {
        if (bugReport == null || bugReport.isCompleted()) {
            return false;
        }
        return addTicket(bugReport);
    }

    public List<Ticket> getTickets() {
        return new ArrayList<>(tickets);
    }

    private boolean addTicket(Ticket ticket) {
        if (getTotalEstimate() + ticket.getEstimate() > timeCapacity || tickets.size() >= ticketsLimit) {
            return false;
        }
        tickets.add(ticket);
        return true;
    }

    private int getTotalEstimate() {
        return tickets.stream().mapToInt(Ticket::getEstimate).sum();
    }

    private boolean checkDependencies(UserStory userStory) {
        return userStory.getDependencies().stream().allMatch(ticket -> tickets.contains(ticket) && ticket.isCompleted());
    }
}
