package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class OrangeHRMTestchatspare {
    public static void main(String[] args) {

        // Setup ChromeDriver
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        // Step 1: Navigate to the OrangeHRM website and verify the URL and title
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        driver.manage().window().maximize();

        // Verify the URL and Title of the page
        String expectedURL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
        String expectedTitle = "OrangeHRM";

        // Get and Print the URL and Title
        String actualURL = driver.getCurrentUrl();
        String actualTitle = driver.getTitle();
        System.out.println("Current URL: " + actualURL);
        System.out.println("Page Title: " + actualTitle);

        // Assertion for URL and Title
        Assert.assertEquals(actualURL, expectedURL);
        Assert.assertEquals(actualTitle, expectedTitle);

        // Step 2: Log in with Admin credentials
        driver.findElement(By.name("username")).sendKeys("Admin");
        driver.findElement(By.name("password")).sendKeys("admin123");
        driver.findElement(By.xpath("//button[@type='submit']")).click();

        // Wait until login is successful
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='PIM']")));

        // Step 3: Navigate to PIM -> Add Employee
        driver.findElement(By.xpath("//span[text()='PIM']")).click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[text()='Add Employee']")));
        driver.findElement(By.xpath("//a[text()='Add Employee']")).click();

        // Step 4: Add Employee details
        driver.findElement(By.name("firstName")).sendKeys("John");
        driver.findElement(By.name("middleName")).sendKeys("A");
        driver.findElement(By.name("lastName")).sendKeys("Doe");

        // Check the "Create Login Details" checkbox
        WebElement createLoginCheckbox = driver.findElement(By.xpath("//input[@id='chkLogin']"));
        if (!createLoginCheckbox.isSelected()) {
            createLoginCheckbox.click();
        }

        // Enter login details for the employee
        driver.findElement(By.id("user_name")).sendKeys("john.doe");
        driver.findElement(By.id("user_password")).sendKeys("Password123");
        driver.findElement(By.id("re_password")).sendKeys("Password123");

        // Save the employee
        driver.findElement(By.id("btnSave")).click();

        // Step 5: Navigate to Admin -> User Management -> Users
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//b[text()='Admin']"))).click();
        driver.findElement(By.xpath("//a[text()='User Management']")).click();
        driver.findElement(By.xpath("//a[text()='Users']")).click();

        // Step 6: Add a new user with Admin role
        driver.findElement(By.id("btnAdd")).click();
        driver.findElement(By.id("systemUser_userType")).sendKeys("Admin"); // Set role as Admin

        // Select employee by name (John Doe)
        driver.findElement(By.id("systemUser_employeeName_empName")).sendKeys("John A Doe");
        driver.findElement(By.id("systemUser_userName")).sendKeys("admin.john");
        driver.findElement(By.id("systemUser_password")).sendKeys("AdminPassword123");
        driver.findElement(By.id("systemUser_confirmPassword")).sendKeys("AdminPassword123");

        // Save the new user
        driver.findElement(By.id("btnSave")).click();

        // Step 7: Log out and log in with the newly created admin user
        driver.findElement(By.id("welcome")).click();
        driver.findElement(By.xpath("//a[text()='Logout']")).click();

        // Log in with new admin credentials
        driver.findElement(By.name("username")).sendKeys("admin.john");
        driver.findElement(By.name("password")).sendKeys("AdminPassword123");
        driver.findElement(By.xpath("//button[@type='submit']")).click();

        // Verify successful login with the new user
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("welcome")));
        System.out.println("Successfully logged in with the new Admin user.");

        // Close the browser
        driver.quit();
    }
}
