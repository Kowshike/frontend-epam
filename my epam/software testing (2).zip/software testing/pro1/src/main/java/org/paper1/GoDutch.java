package org.paper1;


import java.util.Scanner;

public class GoDutch {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read bill total amount
        System.out.println("Enter the bill total amount:");
        int billTotal = scanner.nextInt();

        // Check if bill total amount is negative
        if (billTotal < 0) {
            System.out.println("Bill total amount cannot be negative");
            return;
        }

        // Read number of friends
        System.out.println("Enter the number of friends:");
        int numFriends = scanner.nextInt();

        // Check if number of friends is negative or zero
        if (numFriends <= 0) {
            System.out.println("Number of friends cannot be negative or zero");
            return;
        }

        // Calculate part to pay
        int totalWithTips = (int) (billTotal * 1.1);
        int partToPay = totalWithTips / numFriends;

        // Print the result
        System.out.println("Each friend needs to pay: " + partToPay);
    }
}