package org.example;


import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class drop_box {

    public static void main(String[] args) {
        WebDriver driver;
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get("file:///C:/Users/ACER/OneDrive/Desktop/alert.html"); // Replace with the actual path or URL
        driver.manage().window().maximize();

        // Selecting an option from the dropdown by index
        WebElement dropdownElement = driver.findElement(By.id("namesDropdown")); // Update with the actual ID of the dropdown
        Select dropdownSelect = new Select(dropdownElement);
        dropdownSelect.selectByIndex(3); // Index starts from 0

        // Selecting an option from the dropdown by visible text
        dropdownSelect.selectByVisibleText("Bob");


    }
}
